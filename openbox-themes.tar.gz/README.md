## Openbox Themes
### Collection of 3 theme collections
#### 1. [Openbox Theme Collections by addy-dclvxi](https://github.com/addy-dclxvi/openbox-theme-collections)
#### 2. [Nord Openbox Theme by the-zero885](https://github.com/the-zero885/Nord-Openbox-theme)
#### 3. [Nightmare Themes by MAXIM2](https://www.pling.com/p/1017737)
